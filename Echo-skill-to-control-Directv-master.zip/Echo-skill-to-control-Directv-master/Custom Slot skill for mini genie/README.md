# For Custom Slot mini genie

for the index file added var dtv_Mac the XXXXXXXXXX need to be replaced with your dtv's MAC address
Mac needs to be all caps and no ":"
lines that need to be altered are:
var local_ip = 'xxx.xxx.xxx.xxx';
////////
var dtv_Mac = '&clientAddr=XXXXXXXXXXX';
 //////////////////////////////////////////////////////////
var APP_ID = "amzn1.app_id"; 
///////////////////////////////////////////////////////////////////
/**